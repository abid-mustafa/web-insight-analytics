import { Component } from '@angular/core';
import { SocketService } from '../../services/socket.service';

@Component({
  selector: 'app-realtime',
  standalone: false,
  templateUrl: './realtime.component.html',
  styleUrls: ['./realtime.component.scss']  // Note: Use styleUrls (plural)
})
export class RealtimeComponent {
  pageViews: number = 0;
  bounceRate: number = 0;
  viewCount: number = 0;

  constructor(private socketService: SocketService) {}

  ngOnInit(): void {
    this.socketService.listenForEvent('pageviews').subscribe((data: any) => {
      console.log('Received pageviews:', data);
      this.pageViews = data;
    });
    this.socketService.listenForEvent('bouncerate').subscribe((data: any) => {
      console.log('Received bounce rate:', data);
      this.bounceRate = data;
    });
    this.socketService.listenForEvent('viewcount').subscribe((data: any) => {
      console.log('Received view count:', data);
      this.viewCount = data;
    });
  }
}
