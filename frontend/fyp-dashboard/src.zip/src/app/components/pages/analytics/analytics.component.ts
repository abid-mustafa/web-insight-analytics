import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-analytics',
  standalone: false,
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent {
  inputText: string = '';
  responseData: any;
  tableData: any[] = [];

  constructor(private apiService: ApiService) {}

  onSend(): void {
    this.apiService.fetchAIResponse(this.inputText).subscribe((response: any) => {
      console.log('Received AI response:', response);
      this.responseData = response;
      // If the response is a query and the answer is an object, transform it into table data.
      if (response.promptType === 'query' && typeof response.answer === 'object') {
        this.tableData = Object.entries(response.answer).map(([key, value]) => ({ key, value }));
      }
    });
  }
}
